<?php
add_action('wp_ajax_smartpopup_track', 'smartpopup_log_click');
add_action('wp_ajax_nopriv_smartpopup_track', 'smartpopup_log_click');

function smartpopup_log_click() {
    $type = sanitize_text_field($_GET['track'] ?? '');
    if (!$type) die;

    $clicks = get_option('smartpopup_clicks', []);
    $today = date('Y-m-d');
    if (!isset($clicks[$today])) {
        $clicks[$today] = ['cta' => 0, 'email' => 0, 'phone' => 0];
    }
    if (isset($clicks[$today][$type])) {
        $clicks[$today][$type]++;
    }
    update_option('smartpopup_clicks', $clicks);
    wp_die();
}
