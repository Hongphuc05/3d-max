<?php
/*
Plugin Name: SmartPopup for Blog Posts
Description: Hiển thị popup chỉ trên các bài viết với tùy chỉnh CTA, email, điện thoại và thống kê click.
Version: 1.0
Author: Your Agency
*/
if (!defined('ABSPATH')) exit; // Ngăn truy cập trực tiếp

require_once plugin_dir_path(__FILE__) . 'functions.php';
require_once plugin_dir_path(__FILE__) . 'analytics-report.php';

class SmartPopupPlugin {
    private $option_name = 'smartpopup_settings';

    public function __construct() {
        add_action('admin_menu', [$this, 'create_settings_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_footer', [$this, 'display_popup']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
    }

    public function enqueue_styles() {
        wp_enqueue_style('smartpopup-style', plugin_dir_url(__FILE__) . 'style.css');
    }

    public function create_settings_menu() {
        add_options_page('SmartPopup Settings', 'SmartPopup', 'manage_options', 'smartpopup', [$this, 'settings_page']);
    }

    public function register_settings() {
        register_setting('smartpopup_group', $this->option_name);
    }

    public function settings_page() {
        $settings = get_option($this->option_name);
        ?>
        <div class="wrap">
            <h1>SmartPopup Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('smartpopup_group'); ?>
                <table class="form-table">
                    <tr><th scope="row">Tiêu đề</th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[headline]" value="<?php echo esc_attr($settings['headline'] ?? ''); ?>" class="regular-text" /></td></tr>
                    <tr><th scope="row">Phụ đề</th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[subheadline]" value="<?php echo esc_attr($settings['subheadline'] ?? ''); ?>" class="regular-text" /></td></tr>
                    <tr><th scope="row">Nút CTA - Văn bản</th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[cta_text]" value="<?php echo esc_attr($settings['cta_text'] ?? ''); ?>" class="regular-text" /></td></tr>
                    <tr><th scope="row">Nút CTA - Link</th>
                        <td><input type="url" name="<?php echo $this->option_name; ?>[cta_link]" value="<?php echo esc_attr($settings['cta_link'] ?? ''); ?>" class="regular-text" /></td></tr>
                    <tr><th scope="row">Email liên hệ</th>
                        <td><input type="email" name="<?php echo $this->option_name; ?>[email]" value="<?php echo esc_attr($settings['email'] ?? ''); ?>" class="regular-text" /></td></tr>
                    <tr><th scope="row">Số điện thoại</th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[phone]" value="<?php echo esc_attr($settings['phone'] ?? ''); ?>" class="regular-text" /></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function display_popup() {
        if (!is_single() || !is_main_query()) return;
        $settings = get_option($this->option_name);
        ?>
        <div id="smartpopup" class="smartpopup-container">
            <div class="smartpopup-box">
                <h2><?php echo esc_html($settings['headline'] ?? ''); ?></h2>
                <p><?php echo esc_html($settings['subheadline'] ?? ''); ?></p>
                <a href="<?php echo esc_url($settings['cta_link'] ?? '#'); ?>" class="smartpopup-cta" target="_blank" onclick="smartpopupTrack('cta')"><?php echo esc_html($settings['cta_text'] ?? 'Click tại đây'); ?></a>
                <div class="smartpopup-contact">
                    <?php if (!empty($settings['email'])): ?>
                        <a href="mailto:<?php echo esc_attr($settings['email']); ?>" onclick="smartpopupTrack('email')">Gửi Email</a>
                    <?php endif; ?>
                    <?php if (!empty($settings['phone'])): ?>
                        <a href="tel:<?php echo esc_attr($settings['phone']); ?>" onclick="smartpopupTrack('phone')">Gọi Ngay</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <script>
        function smartpopupTrack(type) {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=smartpopup_track&track=' + type);
        }
        </script>
        <?php
    }
}

new SmartPopupPlugin();
