<?php
if (!wp_next_scheduled('smartpopup_send_report')) {
    wp_schedule_event(time(), 'daily', 'smartpopup_send_report');
}

add_action('smartpopup_send_report', 'smartpopup_send_click_report');

function smartpopup_send_click_report() {
    $clicks = get_option('smartpopup_clicks', []);
    $settings = get_option('smartpopup_settings', []);
    $emails = explode(',', $settings['report_emails'] ?? '');
    $emails = array_map('trim', $emails);
    if (empty($emails) || empty($clicks)) return;

    $message = \"Thống kê click popup:\\n\\n\";
    foreach ($clicks as $date => $data) {
        $message .= \"$date:\\n - CTA: {$data['cta']}\\n - Email: {$data['email']}\\n - Phone: {$data['phone']}\\n\\n\";
    }

    foreach ($emails as $to) {
        wp_mail($to, 'SmartPopup Report', $message);
    }

    // Reset sau khi gửi
    delete_option('smartpopup_clicks');
}
